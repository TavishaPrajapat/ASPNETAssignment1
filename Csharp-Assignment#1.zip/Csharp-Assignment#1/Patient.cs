﻿using System; // Importing the System namespace for basic functionality
using System.Collections.Generic; // Importing the System.Collections.Generic namespace for using collections
using System.Linq; // Importing the System.Linq namespace for LINQ functionality
using System.Text; // Importing the System.Text namespace for string manipulation
using System.Threading.Tasks; // Importing the System.Threading.Tasks namespace for asynchronous programming

namespace Csharp_Assignment_1 // Defining the namespace for the program
{
    public class Patient // Defining the Patient class
    {
        // Properties for patient information
        public string FirstName { get; set; } // Property for the first name of the patient
        public string LastName { get; set; } // Property for the last name of the patient
        public double Weight { get; set; } // Property for the weight of the patient in KG
        public double Height { get; set; } // Property for the height of the patient in Centimeters

        // Custom Constructor for initializing patient properties
        public Patient(string firstName, string lastName, double weight, double height)
        {
            FirstName = firstName; // Assigning the first name provided to the FirstName property
            LastName = lastName; // Assigning the last name provided to the LastName property
            Weight = weight; // Assigning the weight provided to the Weight property
            Height = height; // Assigning the height provided to the Height property
        }

        // Blood Pressure Calculation Method
        public string CalculateBP(int systolic, int diastolic)
        {
            // Blood Pressure Ranges
            const int NormalMaximumSystolic = 120; // Defining the maximum normal systolic pressure
            const int ElevatedMaximumSystolic = 129; // Defining the maximum elevated systolic pressure
            const int Stage1MaximumSystolic = 139; // Defining the maximum systolic pressure for stage 1 hypertension
            const int Stage2MaximumSystolic = 159; // Defining the maximum systolic pressure for stage 2 hypertension
            const int CrisisMinimumDiastolic = 180; // Defining the minimum diastolic pressure for hypertensive crisis

            // Check Blood Pressure Range and return the corresponding status
            if (systolic <= NormalMaximumSystolic && diastolic < 80)
                return "NORMAL"; // Return normal blood pressure status
            else if (systolic <= ElevatedMaximumSystolic)
                return "ELEVATED"; // Return elevated blood pressure status
            else if (systolic <= Stage1MaximumSystolic)
                return "STAGE 1 OF HIGH BLOOD PRESSURE (HYPERTENSION)"; // Return stage 1 hypertension status
            else if (systolic <= Stage2MaximumSystolic)
                return "STAGE 2 HIGH BLOOD PRESSURE (HYPERTENSION)"; // Return stage 2 hypertension status
            else if (systolic >= CrisisMinimumDiastolic)
                return "IF YOU HAVE HYPERTENSIVE CRISIS,CONSULT YOUR DOCTOR IMMEDIATELY)"; // Return hypertensive crisis status
            else
                return "YOUR BLOOD PRESSURE IS NOT IN SPECIFIED RANGE.PLEASE,CONSULT YOUR DOCTOR."; // Return out of range status
        }

        // BMI Calculation Method
        public double BMICalculator()
        {
            // Convert height from centimeters to meters
            double heightInMeters = Height / 100.0; // Convert height to meters

            // Calculate BMI
            return Weight / (heightInMeters * heightInMeters); // Return calculated BMI
        }

        // Patient Information Output Method
        public void PatientInformation(int systolic, int diastolic)
        {
            // Blood Pressure Result
            string BPResult = CalculateBP(systolic, diastolic); // Calculate blood pressure status

            // BMI Result
            double BMIResult = BMICalculator(); // Calculate BMI

            // BMI Status
            string StatusOfBMI = GetBMIStatus(BMIResult); // Get BMI status

            // Display Patient Information
            Console.WriteLine($"Patient Information:\n" + // Display patient information
                              $"Full Name of patient: {FirstName} {LastName}\n" + // Display patient's full name
                              $"Weight of patient in kg: {Weight} KG\n" + // Display patient's weight
                              $"Height of patient in cm: {Height} CM\n" + // Display patient's height
                              $"Blood Pressure of patient: {BPResult}\n" + // Display patient's blood pressure status
                              $"BMI: {BMIResult:F2}\n" + // Display patient's BMI with 2 decimal places
                              $"Status of BMI: {StatusOfBMI}"); // Display patient's BMI status
        }

        // Private method to get BMI Status
        private string GetBMIStatus(double BMI)
        {
            if (BMI >= 25.0)
                return "person is Overweight"; // Return overweight status if BMI is 25 or more
            else if (BMI >= 18.5 && BMI <= 24.9)
                return "person's BMI is Normal (In the healthy range)"; // Return normal status if BMI is between 18.5 and 24.9
            else
                return "person is Underweight"; // Return underweight status for all other cases
        }
    }
}
