﻿using System;// Importing the System namespace for basic functionality

namespace Csharp_Assignment_1// Defining the namespace for the program
{
    class Program// Defining the Program class
    {
        static void Main()// Main method, entry point of the program
        {
            //Ask the user to enter their age
            Console.Write("User,please enter your age: ");// Prompting the user to enter their age
            int userAge = int.Parse(Console.ReadLine());// Reading and parsing the user's age input

            //Ask the user to insert the needed patient information
            Console.WriteLine("\nPlease enter the information of patient:");// Prompting the user for patient information
            Console.Write("Please enter the first name: ");// Prompting for the patient's first name
            string firstName = Console.ReadLine();// Reading the patient's first name

            Console.Write("Please enter the last name: ");// Prompting for the patient's last name
            string lastName = Console.ReadLine();// Reading the patient's last name

            Console.Write("Please enter the weight in KG: ");// Prompting for the patient's weight
            double weight = double.Parse(Console.ReadLine());// Reading and parsing the patient's weight input

            Console.Write("Please enter the Height in CM: ");// Prompting for the patient's height
            double height = double.Parse(Console.ReadLine());// Reading and parsing the patient's height input

            //Create an instance of the Patient class and call the method for printing patient information
            Patient patient = new Patient(firstName, lastName, weight, height);// Creating a new Patient instance
            patient.PatientInformation(userAge, 80); // Displaying patient information with assumed blood pressure values
        }
    }
}
